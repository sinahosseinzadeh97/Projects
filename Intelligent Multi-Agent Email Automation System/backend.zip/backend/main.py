from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import json
import uuid
from datetime import datetime, timedelta

# Create FastAPI app
app = FastAPI(title="Email Automation Demo API")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For demo purposes, allow all origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mock database
class MockDB:
    def __init__(self):
        self.emails = []
        self.users = {
            "admin": {
                "username": "admin",
                "full_name": "Admin User",
                "email": "admin@example.com",
                "hashed_password": "adminpassword",  # In a real app, this would be hashed
                "disabled": False,
            }
        }
        self.providers = []
        self.templates = [
            {
                "id": "template1",
                "category": "important",
                "template": "Thank you for your important message. I've reviewed it and {summary}. I'll {action} as requested."
            },
            {
                "id": "template2",
                "category": "promotional",
                "template": "Thank you for sharing this offer. I'll review the details about {summary} and get back to you if interested."
            },
            {
                "id": "template3",
                "category": "support",
                "template": "Thank you for reaching out to our support team. I understand that {summary}. We'll {action} to resolve this issue."
            }
        ]
        
        # Add some sample emails
        self.add_sample_emails()
    
    def add_sample_emails(self):
        sample_emails = [
            {
                "message_id": f"sample1@example.com",
                "subject": "Project Update Meeting",
                "from_address": "john.doe@example.com",
                "to": "recipient@example.com",
                "cc": "team@example.com",
                "body": "Hello team,\n\nLet's schedule a project update meeting for tomorrow at 2 PM. We need to discuss the current progress and next steps.\n\nRegards,\nJohn",
                "attachments": [],
                "timestamp": (datetime.now() - timedelta(days=1)).isoformat(),
                "classification": {
                    "predicted_category": "important",
                    "confidence": 0.85
                },
                "processed_data": {
                    "summary": "Project update meeting scheduled for tomorrow at 2 PM to discuss progress and next steps.",
                    "extractions": {
                        "dates_times": [
                            {
                                "text": "tomorrow at 2 PM",
                                "type": "datetime"
                            }
                        ],
                        "contacts": [
                            {
                                "text": "John",
                                "type": "person"
                            }
                        ],
                        "tasks": [
                            {
                                "text": "discuss the current progress and next steps",
                                "type": "task"
                            }
                        ]
                    }
                },
                "response_data": {
                    "response_text": "Thank you for your important message. I've reviewed it and noted the project update meeting scheduled for tomorrow at 2 PM to discuss progress and next steps. I'll attend as requested.",
                    "auto_send": True,
                    "confidence": 0.92
                }
            },
            {
                "message_id": f"sample2@example.com",
                "subject": "Weekly Newsletter",
                "from_address": "newsletter@company.com",
                "to": "recipient@example.com",
                "cc": None,
                "body": "This week's newsletter includes updates on new products, upcoming events, and company announcements. Check out our latest blog post!",
                "attachments": [],
                "timestamp": (datetime.now() - timedelta(days=2)).isoformat(),
                "classification": {
                    "predicted_category": "promotional",
                    "confidence": 0.92
                },
                "processed_data": {
                    "summary": "Weekly newsletter with updates on products, events, and company announcements.",
                    "extractions": {
                        "dates_times": [],
                        "contacts": [],
                        "tasks": []
                    }
                },
                "response_data": {
                    "response_text": "Thank you for sharing this offer. I'll review the details about the weekly newsletter with updates on products, events, and company announcements and get back to you if interested.",
                    "auto_send": False,
                    "confidence": 0.75
                }
            },
            {
                "message_id": f"sample3@example.com",
                "subject": "Support Request #12345",
                "from_address": "customer@client.org",
                "to": "support@example.com",
                "cc": "recipient@example.com",
                "body": "I'm experiencing issues with logging into my account. The password reset functionality doesn't seem to be working. Can you please help me resolve this issue?",
                "attachments": [],
                "timestamp": datetime.now().isoformat(),
                "classification": {
                    "predicted_category": "support",
                    "confidence": 0.88
                },
                "processed_data": {
                    "summary": "Customer is having issues logging in and the password reset functionality is not working.",
                    "extractions": {
                        "dates_times": [],
                        "contacts": [],
                        "tasks": [
                            {
                                "text": "help resolve login and password reset issues",
                                "type": "task"
                            }
                        ]
                    }
                },
                "response_data": {
                    "response_text": "Thank you for reaching out to our support team. I understand that you're having issues logging in and the password reset functionality is not working. We'll investigate this issue immediately to resolve it for you.",
                    "auto_send": True,
                    "confidence": 0.89
                }
            }
        ]
        
        for email in sample_emails:
            self.emails.append(email)

# Initialize mock database
db = MockDB()

# Authentication
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Models
class User(BaseModel):
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    disabled: Optional[bool] = None

class UserInDB(User):
    hashed_password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class EmailBase(BaseModel):
    message_id: str
    subject: str
    from_address: str
    to: str
    cc: Optional[str] = None
    body: str
    attachments: List[str] = []

class Classification(BaseModel):
    predicted_category: str
    confidence: float

class Extraction(BaseModel):
    text: str
    type: str

class Extractions(BaseModel):
    dates_times: List[Extraction] = []
    contacts: List[Extraction] = []
    tasks: List[Extraction] = []

class ProcessedData(BaseModel):
    summary: str
    extractions: Extractions

class ResponseData(BaseModel):
    response_text: str
    auto_send: bool
    confidence: float

class Email(EmailBase):
    timestamp: Optional[str] = None
    classification: Optional[Classification] = None
    processed_data: Optional[ProcessedData] = None
    response_data: Optional[ResponseData] = None

class EmailProvider(BaseModel):
    type: str
    server: str
    username: str
    password: str
    folder: str = "INBOX"
    limit: int = 10

class EmailProviderResponse(BaseModel):
    id: str
    type: str
    server: str
    username: str
    folder: str
    limit: int
    created_at: str

class FetchEmailsRequest(BaseModel):
    provider_id: str
    limit: Optional[int] = None

class FetchEmailsResponse(BaseModel):
    emails_fetched: int
    provider_id: str
    status: str

class Template(BaseModel):
    id: str
    category: str
    template: str
    timestamp: Optional[str] = None

class WorkflowResponse(BaseModel):
    start_time: str
    end_time: str
    duration_seconds: float
    emails_processed: int
    emails_with_responses: int
    emails_auto_sent: int
    emails_with_calendar_integration: int
    emails_with_crm_integration: int
    emails_with_task_integration: int
    status: str
    error: Optional[str] = None

class AnalyticsResponse(BaseModel):
    total_emails: int
    emails_by_category: Dict[str, int]
    emails_by_day: List[Dict[str, Any]]
    response_rate: float
    auto_send_rate: float
    average_processing_time: float

# Helper functions
def get_user(db, username: str):
    if username in db.users:
        user_dict = db.users[username]
        return UserInDB(**user_dict)
    return None

def authenticate_user(db, username: str, password: str):
    user = get_user(db, username)
    if not user:
        return False
    if password != user.hashed_password:  # In a real app, use proper password verification
        return False
    return user

async def get_current_user(token: str = Depends(oauth2_scheme)):
    user = get_user(db, token)  # In a real app, verify JWT token
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user

async def get_current_active_user(current_user: User = Depends(get_current_user)):
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

# Routes
@app.get("/")
def read_root():
    return {"message": "Welcome to the Intelligent Multi-Agent Email Automation System API", "version": "1.0.0", "documentation": "/docs"}

@app.get("/health")
def health_check():
    return {"status": "healthy", "database": "healthy", "cache": "healthy", "api": "healthy"}

@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = user.username  # In a real app, generate JWT token
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/users/me/", response_model=User)
async def read_users_me(current_user: User = Depends(get_current_active_user)):
    return current_user

# Email Ingestion Routes
@app.post("/ingestion/providers", response_model=EmailProviderResponse)
async def create_provider(provider: EmailProvider, current_user: User = Depends(get_current_active_user)):
    provider_id = str(uuid.uuid4())
    provider_dict = provider.dict()
    provider_dict["id"] = provider_id
    provider_dict["created_at"] = datetime.now().isoformat()
    db.providers.append(provider_dict)
    
    # Don't return password in response
    response = provider_dict.copy()
    response.pop("password", None)
    return response

@app.get("/ingestion/providers", response_model=List[EmailProviderResponse])
async def get_providers(current_user: User = Depends(get_current_active_user)):
    providers = []
    for provider in db.providers:
        provider_copy = provider.copy()
        provider_copy.pop("password", None)
        providers.append(provider_copy)
    return providers

@app.get("/ingestion/providers/{provider_id}", response_model=EmailProviderResponse)
async def get_provider(provider_id: str, current_user: User = Depends(get_current_active_user)):
    for provider in db.providers:
        if provider["id"] == provider_id:
            provider_copy = provider.copy()
            provider_copy.pop("password", None)
            return provider_copy
    raise HTTPException(status_code=404, detail="Provider not found")

@app.post("/ingestion/fetch", response_model=FetchEmailsResponse)
async def fetch_emails(request: FetchEmailsRequest, current_user: User = Depends(get_current_active_user)):
    # In a real app, this would connect to the email provider and fetch emails
    # For the demo, we'll just return a success response
    return {
        "emails_fetched": 3,
        "provider_id": request.provider_id,
        "status": "success"
    }

# Classification Routes
@app.post("/classification/classify", response_model=Classification)
async def classify_email(email: EmailBase, current_user: User = Depends(get_current_active_user)):
    # In a real app, this would use ML to classify the email
    # For the demo, we'll return a mock classification
    import random
    categories = ["important", "promotional", "support", "spam", "other"]
    category = random.choice(categories)
    confidence = round(random.uniform(0.7, 0.95), 2)
    
    return {
        "predicted_category": category,
        "confidence": confidence
    }

@app.get("/classification/categories")
async def get_categories(current_user: User = Depends(get_current_active_user)):
    return {"categories": ["important", "promotional", "support", "spam", "other"]}

# Summarization Routes
@app.post("/summarization/summarize", response_model=Dict[str, str])
async def summarize_email(email: EmailBase, current_user: User = Depends(get_current_active_user)):
    # In a real app, this would use NLP to summarize the email
    # For the demo, we'll return a mock summary
    words = email.body.split()
    if len(words) > 10:
        summary = " ".join(words[:10]) + "..."
    else:
        summary = email.body
        
    return {
        "message_id": email.message_id,
        "summary": summary
    }

@app.post("/summarization/extract", response_model=Dict[str, Any])
async def extract_data(email: EmailBase, current_user: User = Depends(get_current_active_user)):
    # In a real app, this would use NLP to extract data
    # For the demo, we'll return mock extractions
    extractions = {
        "dates_times": [],
        "contacts": [],
        "tasks": []
    }
    
    # Simple keyword-based extraction for demo
    if "tomorrow" in email.body.lower() or "today" in email.body.lower():
        extractions["dates_times"].append({
            "text": "tomorrow" if "tomorrow" in email.body.lower() else "today",
            "type": "datetime"
        })
    
    if "meeting" in email.body.lower():
        extractions["tasks"].append({
            "text": "attend meeting",
            "type": "task"
        })
        
    # Extract names from signature
    lines = email.body.split('\n')
    for i, line in enumerate(lines):
        if "regards" in line.lower() and i < len(lines) - 1:
            name = lines[i+1].strip()
            if name and len(name.split()) <= 2:
                extractions["contacts"].append({
                    "text": name,
                    "type": "person"
                })
    
    return {
        "message_id": email.message_id,
        "extractions": extractions
    }

# Response Generation Routes
@app.post("/response/generate", response_model=ResponseData)
async def generate_response(email: Dict[str, Any], current_user: User = Depends(get_current_active_user)):
    # In a real app, this would use NLP to generate a response
    # For the demo, we'll use templates
    
    category = email.get("classification", {}).get("predicted_category", "other")
    summary = email.get("processed_data", {}).get("summary", "your message")
    
    # Find template for category
    template = None
    for t in db.templates:
        if t["category"] == category:
            template = t["template"]
            break
    
    if not template:
        template = "Thank you for your message. I've noted that {summary}. I'll get back to you soon."
    
    # Fill in template
    response_text = template.replace("{summary}", summary)
    response_text = response_text.replace("{action}", "follow up")
    
    import random
    confidence = round(random.uniform(0.7, 0.95), 2)
    auto_send = confidence > 0.85
    
    return {
        "response_text": response_text,
        "auto_send": auto_send,
        "confidence": confidence
    }

@app.get("/response/templates", response_model=List[Template])
async def get_templates(current_user: User = Depends(get_current_active_user)):
    return db.templates

# Integration Routes
@app.post("/integration/calendar")
async def create_calendar_event(email: Dict[str, Any], current_user: User = Depends(get_current_active_user)):
    # In a real app, this would create a calendar event
    # For the demo, we'll return a mock response
    return {
        "service": "google_calendar",
        "events_created": [
            {
                "id": str(uuid.uuid4()),
                "title": email.get("subject", "Meeting"),
                "datetime": (datetime.now() + timedelta(days=1)).isoformat(),
                "description": email.get("processed_data", {}).get("summary", ""),
                "attendees": [email.get("from_address", ""), email.get("to", "")],
                "location": None,
                "duration_minutes": 60
            }
        ],
        "status": "success",
        "timestamp": datetime.now().isoformat()
    }

@app.post("/integration/workflow", response_model=WorkflowResponse)
async def run_workflow(emails: List[Dict[str, Any]], current_user: User = Depends(get_current_active_user)):
    # In a real app, this would process emails through the entire workflow
    # For the demo, we'll return a mock response
    start_time = datetime.now()
    end_time = start_time + timedelta(seconds=5)
    
    emails_with_responses = sum(1 for e in emails if "response_data" in e)
    emails_auto_sent = sum(1 for e in emails if e.get("response_data", {}).get("auto_send", False))
    
    return {
        "start_time": start_time.isoformat(),
        "end_time": end_time.isoformat(),
        "duration_seconds": 5.0,
        "emails_processed": len(emails),
        "emails_with_responses": emails_with_responses,
        "emails_auto_sent": emails_auto_sent,
        "emails_with_calendar_integration": 1,
        "emails_with_crm_integration": 1,
        "emails_with_task_integration": 1,
        "status": "completed",
        "error": None
    }

# Email Management Routes
@app.get("/emails", response_model=List[Email])
async def get_emails(current_user: User = Depends(get_current_active_user)):
    return db.emails

@app.get("/emails/{message_id}", response_model=Email)
async def get_email(message_id: str, current_user: User = Depends(get_current_active_user)):
    for email in db.emails:
        if email["message_id"] == message_id:
            return email
    raise HTTPException(status_code=404, detail="Email not found")

# Analytics Routes
@app.get("/analytics/emails", response_model=AnalyticsResponse)
async def get_email_analytics(current_user: User = Depends(get_current_active_user)):
    # In a real app, this would query the database for analytics
    # For the demo, we'll return mock analytics
    
    # Count emails by category
    emails_by_category = {}
    for email in db.emails:
        category = email.get("classification", {}).get("predicted_category", "other")
        emails_by_category[category] = emails_by_category.get(category, 0) + 1
    
    # Count emails by day
    emails_by_day = [
        {"date": (datetime.now() - timedelta(days=6)).strftime("%Y-%m-%d"), "count": 32},
        {"date": (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d"), "count": 45},
        {"date": (datetime.now() - timedelta(days=4)).strftime("%Y-%m-%d"), "count": 38},
        {"date": (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d"), "count": 52},
        {"date": (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d"), "count": 48},
        {"date": (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d"), "count": 23},
        {"date": datetime.now().strftime("%Y-%m-%d"), "count": 18}
    ]
    
    return {
        "total_emails": len(db.emails),
        "emails_by_category": emails_by_category,
        "emails_by_day": emails_by_day,
        "response_rate": 0.89,
        "auto_send_rate": 0.65,
        "average_processing_time": 3.2
    }

# Run the application
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
