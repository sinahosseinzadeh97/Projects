import React, { useState, useEffect } from 'react';
import { Container, Typography, Grid, Paper, Box, CircularProgress } from '@mui/material';
import { styled } from '@mui/material/styles';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from 'recharts';
import { getEmailAnalytics } from '../services/api';

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: 'flex',
  overflow: 'auto',
  flexDirection: 'column',
}));

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

function Analytics() {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const data = await getEmailAnalytics();
        setAnalytics(data);
      } catch (err) {
        console.error('Error fetching analytics:', err);
        setError('Failed to load analytics data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography color="error" variant="h6" gutterBottom>
          {error}
        </Typography>
      </Container>
    );
  }

  // Prepare data for pie chart
  const pieData = analytics ? Object.entries(analytics.emails_by_category).map(([name, value]) => ({
    name,
    value
  })) : [];

  // Prepare data for response rate over time
  const responseRateData = [
    { date: '2023-04-08', rate: 0.82 },
    { date: '2023-04-09', rate: 0.85 },
    { date: '2023-04-10', rate: 0.79 },
    { date: '2023-04-11', rate: 0.88 },
    { date: '2023-04-12', rate: 0.91 },
    { date: '2023-04-13', rate: 0.87 },
    { date: '2023-04-14', rate: 0.89 }
  ];

  // Prepare data for processing time
  const processingTimeData = [
    { category: 'Important', time: 2.8 },
    { category: 'Promotional', time: 1.9 },
    { category: 'Support', time: 3.5 },
    { category: 'Spam', time: 1.2 },
    { category: 'Other', time: 2.4 }
  ];

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography component="h1" variant="h4" gutterBottom>
        Analytics Dashboard
      </Typography>
      
      <Grid container spacing={3}>
        {/* Summary Stats */}
        <Grid item xs={12} md={3}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Total Emails
            </Typography>
            <Typography component="p" variant="h3">
              {analytics?.total_emails || 0}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={3}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Response Rate
            </Typography>
            <Typography component="p" variant="h3">
              {analytics ? `${(analytics.response_rate * 100).toFixed(1)}%` : '0%'}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={3}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Auto-Send Rate
            </Typography>
            <Typography component="p" variant="h3">
              {analytics ? `${(analytics.auto_send_rate * 100).toFixed(1)}%` : '0%'}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={3}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Avg. Processing Time
            </Typography>
            <Typography component="p" variant="h3">
              {analytics ? `${analytics.average_processing_time.toFixed(1)}s` : '0s'}
            </Typography>
          </StyledPaper>
        </Grid>

        {/* Email Volume Chart */}
        <Grid item xs={12} md={8}>
          <StyledPaper sx={{ height: 300 }}>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Email Volume (Last 7 Days)
            </Typography>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={analytics?.emails_by_day || []}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="count" fill="#8884d8" name="Emails" />
              </BarChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>

        {/* Email Categories Chart */}
        <Grid item xs={12} md={4}>
          <StyledPaper sx={{ height: 300 }}>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Email Categories
            </Typography>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>

        {/* Response Rate Over Time */}
        <Grid item xs={12} md={6}>
          <StyledPaper sx={{ height: 300 }}>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Response Rate Over Time
            </Typography>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={responseRateData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis domain={[0, 1]} tickFormatter={(value) => `${(value * 100).toFixed(0)}%`} />
                <Tooltip formatter={(value) => `${(value * 100).toFixed(1)}%`} />
                <Legend />
                <Line type="monotone" dataKey="rate" stroke="#82ca9d" name="Response Rate" />
              </LineChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>

        {/* Processing Time by Category */}
        <Grid item xs={12} md={6}>
          <StyledPaper sx={{ height: 300 }}>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Processing Time by Category
            </Typography>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={processingTimeData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="category" />
                <YAxis label={{ value: 'Seconds', angle: -90, position: 'insideLeft' }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="time" fill="#ff8042" name="Processing Time (s)" />
              </BarChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>

        {/* Additional Analytics Information */}
        <Grid item xs={12}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              System Performance
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3, mt: 2 }}>
              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Classification Accuracy
                </Typography>
                <Typography variant="h6">
                  92.5%
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Summarization Quality
                </Typography>
                <Typography variant="h6">
                  87.3%
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Response Acceptance Rate
                </Typography>
                <Typography variant="h6">
                  94.1%
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Calendar Events Created
                </Typography>
                <Typography variant="h6">
                  28
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  CRM Entries Updated
                </Typography>
                <Typography variant="h6">
                  43
                </Typography>
              </Box>
              <Box>
                <Typography variant="subtitle2" color="textSecondary">
                  Tasks Created
                </Typography>
                <Typography variant="h6">
                  37
                </Typography>
              </Box>
            </Box>
          </StyledPaper>
        </Grid>
      </Grid>
    </Container>
  );
}

export default Analytics;
