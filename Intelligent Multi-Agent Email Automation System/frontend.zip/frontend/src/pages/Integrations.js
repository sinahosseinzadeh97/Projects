import React, { useState } from 'react';
import { Container, Typography, Grid, Paper, Box, Button, TextField, FormControl, InputLabel, Select, MenuItem, Chip, CircularProgress } from '@mui/material';
import { styled } from '@mui/material/styles';

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: 'flex',
  overflow: 'auto',
  flexDirection: 'column',
}));

function Integrations() {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('email');
  const [emailProvider, setEmailProvider] = useState({
    type: 'gmail',
    server: '',
    username: '',
    password: '',
    folder: 'INBOX',
    limit: 10
  });
  const [calendarProvider, setCalendarProvider] = useState({
    type: 'google',
    apiKey: '',
    calendarId: ''
  });
  const [crmProvider, setCrmProvider] = useState({
    type: 'salesforce',
    apiKey: '',
    instanceUrl: '',
    username: ''
  });
  const [taskProvider, setTaskProvider] = useState({
    type: 'asana',
    apiKey: '',
    workspaceId: ''
  });

  const handleEmailChange = (field) => (event) => {
    setEmailProvider({
      ...emailProvider,
      [field]: event.target.value
    });
  };

  const handleCalendarChange = (field) => (event) => {
    setCalendarProvider({
      ...calendarProvider,
      [field]: event.target.value
    });
  };

  const handleCrmChange = (field) => (event) => {
    setCrmProvider({
      ...crmProvider,
      [field]: event.target.value
    });
  };

  const handleTaskChange = (field) => (event) => {
    setTaskProvider({
      ...taskProvider,
      [field]: event.target.value
    });
  };

  const handleSaveIntegration = () => {
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      alert(`${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} integration saved successfully!`);
    }, 1000);
  };

  const renderEmailForm = () => (
    <Box>
      <FormControl fullWidth margin="normal">
        <InputLabel>Provider Type</InputLabel>
        <Select
          value={emailProvider.type}
          onChange={handleEmailChange('type')}
          label="Provider Type"
        >
          <MenuItem value="gmail">Gmail</MenuItem>
          <MenuItem value="outlook">Outlook</MenuItem>
          <MenuItem value="imap">IMAP</MenuItem>
          <MenuItem value="exchange">Exchange</MenuItem>
        </Select>
      </FormControl>
      
      {emailProvider.type === 'imap' && (
        <TextField
          label="Server"
          value={emailProvider.server}
          onChange={handleEmailChange('server')}
          fullWidth
          margin="normal"
        />
      )}
      
      <TextField
        label="Username/Email"
        value={emailProvider.username}
        onChange={handleEmailChange('username')}
        fullWidth
        margin="normal"
      />
      
      <TextField
        label="Password/App Password"
        type="password"
        value={emailProvider.password}
        onChange={handleEmailChange('password')}
        fullWidth
        margin="normal"
      />
      
      <TextField
        label="Folder"
        value={emailProvider.folder}
        onChange={handleEmailChange('folder')}
        fullWidth
        margin="normal"
      />
      
      <TextField
        label="Email Limit"
        type="number"
        value={emailProvider.limit}
        onChange={handleEmailChange('limit')}
        fullWidth
        margin="normal"
        InputProps={{ inputProps: { min: 1, max: 100 } }}
      />
    </Box>
  );

  const renderCalendarForm = () => (
    <Box>
      <FormControl fullWidth margin="normal">
        <InputLabel>Calendar Provider</InputLabel>
        <Select
          value={calendarProvider.type}
          onChange={handleCalendarChange('type')}
          label="Calendar Provider"
        >
          <MenuItem value="google">Google Calendar</MenuItem>
          <MenuItem value="outlook">Outlook Calendar</MenuItem>
          <MenuItem value="ical">iCalendar</MenuItem>
        </Select>
      </FormControl>
      
      <TextField
        label="API Key"
        value={calendarProvider.apiKey}
        onChange={handleCalendarChange('apiKey')}
        fullWidth
        margin="normal"
      />
      
      <TextField
        label="Calendar ID"
        value={calendarProvider.calendarId}
        onChange={handleCalendarChange('calendarId')}
        fullWidth
        margin="normal"
        helperText="Leave blank for primary calendar"
      />
    </Box>
  );

  const renderCrmForm = () => (
    <Box>
      <FormControl fullWidth margin="normal">
        <InputLabel>CRM Provider</InputLabel>
        <Select
          value={crmProvider.type}
          onChange={handleCrmChange('type')}
          label="CRM Provider"
        >
          <MenuItem value="salesforce">Salesforce</MenuItem>
          <MenuItem value="hubspot">HubSpot</MenuItem>
          <MenuItem value="zoho">Zoho CRM</MenuItem>
        </Select>
      </FormControl>
      
      <TextField
        label="API Key"
        value={crmProvider.apiKey}
        onChange={handleCrmChange('apiKey')}
        fullWidth
        margin="normal"
      />
      
      <TextField
        label="Instance URL"
        value={crmProvider.instanceUrl}
        onChange={handleCrmChange('instanceUrl')}
        fullWidth
        margin="normal"
      />
      
      <TextField
        label="Username"
        value={crmProvider.username}
        onChange={handleCrmChange('username')}
        fullWidth
        margin="normal"
      />
    </Box>
  );

  const renderTaskForm = () => (
    <Box>
      <FormControl fullWidth margin="normal">
        <InputLabel>Task Management Provider</InputLabel>
        <Select
          value={taskProvider.type}
          onChange={handleTaskChange('type')}
          label="Task Management Provider"
        >
          <MenuItem value="asana">Asana</MenuItem>
          <MenuItem value="trello">Trello</MenuItem>
          <MenuItem value="jira">Jira</MenuItem>
        </Select>
      </FormControl>
      
      <TextField
        label="API Key"
        value={taskProvider.apiKey}
        onChange={handleTaskChange('apiKey')}
        fullWidth
        margin="normal"
      />
      
      <TextField
        label="Workspace/Board ID"
        value={taskProvider.workspaceId}
        onChange={handleTaskChange('workspaceId')}
        fullWidth
        margin="normal"
      />
    </Box>
  );

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography component="h1" variant="h4" gutterBottom>
        Integrations
      </Typography>
      
      <Grid container spacing={3}>
        {/* Integration Types */}
        <Grid item xs={12} md={3}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Integration Types
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {['email', 'calendar', 'crm', 'task'].map((type) => (
                <Button
                  key={type}
                  variant={activeTab === type ? 'contained' : 'outlined'}
                  onClick={() => setActiveTab(type)}
                  sx={{ justifyContent: 'flex-start', textTransform: 'capitalize' }}
                >
                  {type} Integration
                </Button>
              ))}
            </Box>
          </StyledPaper>
        </Grid>

        {/* Integration Form */}
        <Grid item xs={12} md={9}>
          <StyledPaper>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography component="h2" variant="h6" color="primary">
                {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Integration
              </Typography>
              <Chip
                label="Connected"
                color="success"
                variant="outlined"
                sx={{ visibility: activeTab === 'email' ? 'visible' : 'hidden' }}
              />
            </Box>
            
            {activeTab === 'email' && renderEmailForm()}
            {activeTab === 'calendar' && renderCalendarForm()}
            {activeTab === 'crm' && renderCrmForm()}
            {activeTab === 'task' && renderTaskForm()}
            
            <Box sx={{ mt: 3, display: 'flex', gap: 2 }}>
              <Button
                variant="contained"
                color="primary"
                onClick={handleSaveIntegration}
                disabled={loading}
              >
                {loading ? <CircularProgress size={24} /> : 'Save Integration'}
              </Button>
              <Button
                variant="outlined"
                color="primary"
                disabled={loading}
              >
                Test Connection
              </Button>
            </Box>
          </StyledPaper>
        </Grid>
      </Grid>
    </Container>
  );
}

export default Integrations;
