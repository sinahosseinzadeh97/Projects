import React, { useState, useEffect } from 'react';
import { Container, Typography, Grid, Paper, Box, CircularProgress, TextField, Button, Switch, FormControlLabel, Divider } from '@mui/material';
import { styled } from '@mui/material/styles';
import { getTemplates } from '../services/api';

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: 'flex',
  overflow: 'auto',
  flexDirection: 'column',
}));

function Settings() {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [settings, setSettings] = useState({
    autoClassify: true,
    autoSummarize: true,
    autoRespond: true,
    autoSendThreshold: 0.85,
    pollingInterval: 5,
    maxEmailsPerFetch: 10,
    notifyOnImportant: true,
    notifyOnResponse: false
  });

  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        const data = await getTemplates();
        setTemplates(data);
      } catch (err) {
        console.error('Error fetching templates:', err);
        setError('Failed to load response templates. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchTemplates();
  }, []);

  const handleSettingChange = (setting) => (event) => {
    const value = event.target.type === 'checkbox' ? event.target.checked : event.target.value;
    setSettings({
      ...settings,
      [setting]: value
    });
  };

  const handleTemplateChange = (index, field) => (event) => {
    const newTemplates = [...templates];
    newTemplates[index] = {
      ...newTemplates[index],
      [field]: event.target.value
    };
    setTemplates(newTemplates);
  };

  const handleSaveSettings = () => {
    // In a real app, this would save settings to the backend
    alert('Settings saved successfully!');
  };

  const handleSaveTemplates = () => {
    // In a real app, this would save templates to the backend
    alert('Templates saved successfully!');
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography color="error" variant="h6" gutterBottom>
          {error}
        </Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography component="h1" variant="h4" gutterBottom>
        System Settings
      </Typography>
      
      <Grid container spacing={3}>
        {/* General Settings */}
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              General Settings
            </Typography>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle1" gutterBottom>
                Email Processing
              </Typography>
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.autoClassify}
                    onChange={handleSettingChange('autoClassify')}
                    color="primary"
                  />
                }
                label="Automatically classify emails"
              />
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.autoSummarize}
                    onChange={handleSettingChange('autoSummarize')}
                    color="primary"
                  />
                }
                label="Automatically summarize emails"
              />
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.autoRespond}
                    onChange={handleSettingChange('autoRespond')}
                    color="primary"
                  />
                }
                label="Automatically generate responses"
              />
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle1" gutterBottom>
                Email Retrieval
              </Typography>
              <TextField
                label="Polling Interval (minutes)"
                type="number"
                value={settings.pollingInterval}
                onChange={handleSettingChange('pollingInterval')}
                fullWidth
                margin="normal"
                InputProps={{ inputProps: { min: 1, max: 60 } }}
              />
              <TextField
                label="Maximum Emails Per Fetch"
                type="number"
                value={settings.maxEmailsPerFetch}
                onChange={handleSettingChange('maxEmailsPerFetch')}
                fullWidth
                margin="normal"
                InputProps={{ inputProps: { min: 1, max: 100 } }}
              />
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle1" gutterBottom>
                Response Settings
              </Typography>
              <TextField
                label="Auto-Send Confidence Threshold"
                type="number"
                value={settings.autoSendThreshold}
                onChange={handleSettingChange('autoSendThreshold')}
                fullWidth
                margin="normal"
                InputProps={{ inputProps: { min: 0, max: 1, step: 0.05 } }}
                helperText="Responses with confidence above this threshold will be sent automatically"
              />
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle1" gutterBottom>
                Notifications
              </Typography>
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.notifyOnImportant}
                    onChange={handleSettingChange('notifyOnImportant')}
                    color="primary"
                  />
                }
                label="Notify on important emails"
              />
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.notifyOnResponse}
                    onChange={handleSettingChange('notifyOnResponse')}
                    color="primary"
                  />
                }
                label="Notify when responses are sent"
              />
            </Box>
            
            <Button
              variant="contained"
              color="primary"
              onClick={handleSaveSettings}
              sx={{ mt: 2 }}
            >
              Save Settings
            </Button>
          </StyledPaper>
        </Grid>

        {/* Response Templates */}
        <Grid item xs={12} md={6}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Response Templates
            </Typography>
            
            {templates.map((template, index) => (
              <Box key={template.id} sx={{ mb: 3 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Template for {template.category} emails
                </Typography>
                <TextField
                  label="Template Text"
                  multiline
                  rows={4}
                  value={template.template}
                  onChange={handleTemplateChange(index, 'template')}
                  fullWidth
                  margin="normal"
                  helperText="Use {summary} and {action} as placeholders"
                />
                <Divider sx={{ my: 2 }} />
              </Box>
            ))}
            
            <Button
              variant="contained"
              color="primary"
              onClick={handleSaveTemplates}
              sx={{ mt: 2 }}
            >
              Save Templates
            </Button>
          </StyledPaper>
        </Grid>
      </Grid>
    </Container>
  );
}

export default Settings;
