import React, { useState, useEffect } from 'react';
import { Container, Typography, Grid, Paper, Box, CircularProgress } from '@mui/material';
import { styled } from '@mui/material/styles';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { getEmailAnalytics, getEmails } from '../services/api';

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: 'flex',
  overflow: 'auto',
  flexDirection: 'column',
}));

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

function Dashboard() {
  const [analytics, setAnalytics] = useState(null);
  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [analyticsData, emailsData] = await Promise.all([
          getEmailAnalytics(),
          getEmails()
        ]);
        setAnalytics(analyticsData);
        setEmails(emailsData);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography color="error" variant="h6" gutterBottom>
          {error}
        </Typography>
      </Container>
    );
  }

  // Prepare data for pie chart
  const pieData = analytics ? Object.entries(analytics.emails_by_category).map(([name, value]) => ({
    name,
    value
  })) : [];

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Grid container spacing={3}>
        {/* Summary Stats */}
        <Grid item xs={12} md={4}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Total Emails
            </Typography>
            <Typography component="p" variant="h3">
              {analytics?.total_emails || 0}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={4}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Response Rate
            </Typography>
            <Typography component="p" variant="h3">
              {analytics ? `${(analytics.response_rate * 100).toFixed(1)}%` : '0%'}
            </Typography>
          </StyledPaper>
        </Grid>
        <Grid item xs={12} md={4}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Auto-Send Rate
            </Typography>
            <Typography component="p" variant="h3">
              {analytics ? `${(analytics.auto_send_rate * 100).toFixed(1)}%` : '0%'}
            </Typography>
          </StyledPaper>
        </Grid>

        {/* Email Volume Chart */}
        <Grid item xs={12} md={8}>
          <StyledPaper sx={{ height: 300 }}>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Email Volume (Last 7 Days)
            </Typography>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={analytics?.emails_by_day || []}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="count" fill="#8884d8" name="Emails" />
              </BarChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>

        {/* Email Categories Chart */}
        <Grid item xs={12} md={4}>
          <StyledPaper sx={{ height: 300 }}>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Email Categories
            </Typography>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </StyledPaper>
        </Grid>

        {/* Recent Emails */}
        <Grid item xs={12}>
          <StyledPaper>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Recent Emails
            </Typography>
            <Box sx={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    <th style={{ textAlign: 'left', padding: '8px', borderBottom: '1px solid #ddd' }}>Subject</th>
                    <th style={{ textAlign: 'left', padding: '8px', borderBottom: '1px solid #ddd' }}>From</th>
                    <th style={{ textAlign: 'left', padding: '8px', borderBottom: '1px solid #ddd' }}>Category</th>
                    <th style={{ textAlign: 'left', padding: '8px', borderBottom: '1px solid #ddd' }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {emails.slice(0, 5).map((email) => (
                    <tr key={email.message_id}>
                      <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>{email.subject}</td>
                      <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>{email.from_address}</td>
                      <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>{email.classification?.predicted_category || 'Unclassified'}</td>
                      <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>
                        {email.response_data ? (email.response_data.auto_send ? 'Auto-Replied' : 'Response Ready') : 'Processing'}
                      </td>
                    </tr>
                  ))}
                  {emails.length === 0 && (
                    <tr>
                      <td colSpan={4} style={{ textAlign: 'center', padding: '16px' }}>
                        No emails found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </Box>
          </StyledPaper>
        </Grid>
      </Grid>
    </Container>
  );
}

export default Dashboard;
