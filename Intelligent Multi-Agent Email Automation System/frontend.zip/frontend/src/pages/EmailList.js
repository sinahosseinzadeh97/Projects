import React, { useState, useEffect } from 'react';
import { Container, Typography, Grid, Paper, Box, CircularProgress, Button, Chip } from '@mui/material';
import { styled } from '@mui/material/styles';
import { getEmails } from '../services/api';

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: 'flex',
  overflow: 'auto',
  flexDirection: 'column',
}));

function EmailList() {
  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedEmail, setSelectedEmail] = useState(null);

  useEffect(() => {
    const fetchEmails = async () => {
      try {
        const data = await getEmails();
        setEmails(data);
      } catch (err) {
        console.error('Error fetching emails:', err);
        setError('Failed to load emails. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchEmails();
  }, []);

  const handleEmailSelect = (email) => {
    setSelectedEmail(email);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography color="error" variant="h6" gutterBottom>
          {error}
        </Typography>
      </Container>
    );
  }

  const getCategoryColor = (category) => {
    switch (category) {
      case 'important':
        return '#f44336';
      case 'promotional':
        return '#2196f3';
      case 'support':
        return '#4caf50';
      case 'spam':
        return '#ff9800';
      default:
        return '#9e9e9e';
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography component="h1" variant="h4" gutterBottom>
        Email Management
      </Typography>
      
      <Grid container spacing={3}>
        {/* Email List */}
        <Grid item xs={12} md={5}>
          <StyledPaper sx={{ height: 'calc(100vh - 180px)', overflowY: 'auto' }}>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Emails
            </Typography>
            {emails.length === 0 ? (
              <Typography variant="body1" sx={{ p: 2 }}>
                No emails found
              </Typography>
            ) : (
              emails.map((email) => (
                <Box
                  key={email.message_id}
                  sx={{
                    p: 2,
                    mb: 1,
                    border: '1px solid #e0e0e0',
                    borderRadius: 1,
                    cursor: 'pointer',
                    backgroundColor: selectedEmail?.message_id === email.message_id ? '#f5f5f5' : 'transparent',
                    '&:hover': {
                      backgroundColor: '#f5f5f5',
                    },
                  }}
                  onClick={() => handleEmailSelect(email)}
                >
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                    <Typography variant="subtitle1" fontWeight="bold">
                      {email.subject}
                    </Typography>
                    <Chip
                      label={email.classification?.predicted_category || 'unclassified'}
                      size="small"
                      sx={{
                        backgroundColor: getCategoryColor(email.classification?.predicted_category),
                        color: 'white',
                      }}
                    />
                  </Box>
                  <Typography variant="body2" color="textSecondary">
                    From: {email.from_address}
                  </Typography>
                  <Typography variant="body2" noWrap sx={{ mt: 1 }}>
                    {email.body.substring(0, 100)}...
                  </Typography>
                </Box>
              ))
            )}
          </StyledPaper>
        </Grid>

        {/* Email Details */}
        <Grid item xs={12} md={7}>
          <StyledPaper sx={{ height: 'calc(100vh - 180px)', overflowY: 'auto' }}>
            {selectedEmail ? (
              <>
                <Typography component="h2" variant="h6" color="primary" gutterBottom>
                  Email Details
                </Typography>
                <Box sx={{ mb: 3 }}>
                  <Typography variant="h5" gutterBottom>
                    {selectedEmail.subject}
                  </Typography>
                  <Typography variant="body2" color="textSecondary" gutterBottom>
                    From: {selectedEmail.from_address}
                  </Typography>
                  <Typography variant="body2" color="textSecondary" gutterBottom>
                    To: {selectedEmail.to}
                  </Typography>
                  {selectedEmail.cc && (
                    <Typography variant="body2" color="textSecondary" gutterBottom>
                      CC: {selectedEmail.cc}
                    </Typography>
                  )}
                  <Typography variant="body2" color="textSecondary" gutterBottom>
                    Date: {new Date(selectedEmail.timestamp).toLocaleString()}
                  </Typography>
                </Box>

                <Box sx={{ mb: 3 }}>
                  <Typography variant="body1" sx={{ whiteSpace: 'pre-line' }}>
                    {selectedEmail.body}
                  </Typography>
                </Box>

                <Box sx={{ mb: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Classification
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <Typography variant="body1" sx={{ mr: 1 }}>
                      Category:
                    </Typography>
                    <Chip
                      label={selectedEmail.classification?.predicted_category || 'unclassified'}
                      size="small"
                      sx={{
                        backgroundColor: getCategoryColor(selectedEmail.classification?.predicted_category),
                        color: 'white',
                      }}
                    />
                  </Box>
                  <Typography variant="body2" gutterBottom>
                    Confidence: {(selectedEmail.classification?.confidence * 100).toFixed(1)}%
                  </Typography>
                </Box>

                <Box sx={{ mb: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Summary & Extractions
                  </Typography>
                  <Typography variant="body1" gutterBottom>
                    {selectedEmail.processed_data?.summary || 'No summary available'}
                  </Typography>
                  
                  {selectedEmail.processed_data?.extractions && (
                    <Box sx={{ mt: 2 }}>
                      {selectedEmail.processed_data.extractions.dates_times.length > 0 && (
                        <Box sx={{ mb: 1 }}>
                          <Typography variant="subtitle2">Dates & Times:</Typography>
                          {selectedEmail.processed_data.extractions.dates_times.map((item, index) => (
                            <Chip key={index} label={item.text} size="small" sx={{ mr: 1, mb: 1 }} />
                          ))}
                        </Box>
                      )}
                      
                      {selectedEmail.processed_data.extractions.contacts.length > 0 && (
                        <Box sx={{ mb: 1 }}>
                          <Typography variant="subtitle2">Contacts:</Typography>
                          {selectedEmail.processed_data.extractions.contacts.map((item, index) => (
                            <Chip key={index} label={item.text} size="small" sx={{ mr: 1, mb: 1 }} />
                          ))}
                        </Box>
                      )}
                      
                      {selectedEmail.processed_data.extractions.tasks.length > 0 && (
                        <Box sx={{ mb: 1 }}>
                          <Typography variant="subtitle2">Tasks:</Typography>
                          {selectedEmail.processed_data.extractions.tasks.map((item, index) => (
                            <Chip key={index} label={item.text} size="small" sx={{ mr: 1, mb: 1 }} />
                          ))}
                        </Box>
                      )}
                    </Box>
                  )}
                </Box>

                <Box sx={{ mb: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Generated Response
                  </Typography>
                  <Paper variant="outlined" sx={{ p: 2, backgroundColor: '#f8f9fa' }}>
                    <Typography variant="body1" sx={{ whiteSpace: 'pre-line' }}>
                      {selectedEmail.response_data?.response_text || 'No response generated yet'}
                    </Typography>
                  </Paper>
                  <Box sx={{ mt: 2, display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="body2">
                      Confidence: {selectedEmail.response_data ? (selectedEmail.response_data.confidence * 100).toFixed(1) + '%' : 'N/A'}
                    </Typography>
                    <Typography variant="body2">
                      Auto-send: {selectedEmail.response_data?.auto_send ? 'Yes' : 'No'}
                    </Typography>
                  </Box>
                  <Box sx={{ mt: 2, display: 'flex', gap: 2 }}>
                    <Button variant="contained" color="primary">
                      Send Response
                    </Button>
                    <Button variant="outlined">
                      Edit Response
                    </Button>
                  </Box>
                </Box>
              </>
            ) : (
              <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                <Typography variant="body1" color="textSecondary">
                  Select an email to view details
                </Typography>
              </Box>
            )}
          </StyledPaper>
        </Grid>
      </Grid>
    </Container>
  );
}

export default EmailList;
