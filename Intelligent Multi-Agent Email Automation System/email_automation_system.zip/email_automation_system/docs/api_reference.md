# API Documentation

## Overview

The Intelligent Multi-Agent Email Automation System provides a comprehensive RESTful API that allows developers to interact with all aspects of the system. This document details the available endpoints, request/response formats, and authentication requirements.

## Base URL

All API endpoints are relative to the base URL:

```
http://your-server-address:8000
```

For production environments, HTTPS should be used:

```
https://your-server-address
```

## Authentication

### Obtaining an Access Token

All API endpoints (except the health check and root endpoint) require authentication using JWT tokens.

**Endpoint**: `POST /token`

**Request Body**:
```json
{
  "username": "your_username",
  "password": "your_password"
}
```

**Response**:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

**Status Codes**:
- `200 OK`: Authentication successful
- `401 Unauthorized`: Invalid credentials

### Using the Access Token

Include the access token in the `Authorization` header of all API requests:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## API Endpoints

### System Information

#### Get API Information

**Endpoint**: `GET /`

**Description**: Returns basic information about the API.

**Authentication**: Not required

**Response**:
```json
{
  "message": "Welcome to the Intelligent Multi-Agent Email Automation System API",
  "version": "1.0.0",
  "documentation": "/docs"
}
```

**Status Codes**:
- `200 OK`: Request successful

#### Health Check

**Endpoint**: `GET /health`

**Description**: Checks the health status of the API and its dependencies.

**Authentication**: Not required

**Response**:
```json
{
  "status": "healthy",
  "database": "healthy",
  "cache": "healthy",
  "api": "healthy"
}
```

**Status Codes**:
- `200 OK`: Request successful

#### Get Current User

**Endpoint**: `GET /users/me/`

**Description**: Returns information about the currently authenticated user.

**Authentication**: Required

**Response**:
```json
{
  "username": "admin",
  "email": "admin@example.com",
  "full_name": "Admin User",
  "disabled": false,
  "roles": ["admin"]
}
```

**Status Codes**:
- `200 OK`: Request successful
- `401 Unauthorized`: Invalid or missing token

### Email Ingestion

#### Create Email Provider

**Endpoint**: `POST /ingestion/providers`

**Description**: Creates a new email provider configuration.

**Authentication**: Required

**Request Body**:
```json
{
  "type": "gmail",
  "server": "imap.gmail.com",
  "username": "your_email@gmail.com",
  "password": "your_password",
  "folder": "INBOX",
  "limit": 10
}
```

**Response**:
```json
{
  "id": "provider_id",
  "type": "gmail",
  "server": "imap.gmail.com",
  "username": "your_email@gmail.com",
  "folder": "INBOX",
  "limit": 10,
  "created_at": "2025-04-14T08:00:00Z"
}
```

**Status Codes**:
- `200 OK`: Provider created successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token

#### Get Email Providers

**Endpoint**: `GET /ingestion/providers`

**Description**: Returns a list of all email provider configurations.

**Authentication**: Required

**Response**:
```json
[
  {
    "id": "provider_id_1",
    "type": "gmail",
    "server": "imap.gmail.com",
    "username": "your_email@gmail.com",
    "folder": "INBOX",
    "limit": 10,
    "created_at": "2025-04-14T08:00:00Z"
  },
  {
    "id": "provider_id_2",
    "type": "outlook",
    "server": "outlook.office365.com",
    "username": "your_email@outlook.com",
    "folder": "INBOX",
    "limit": 20,
    "created_at": "2025-04-14T09:00:00Z"
  }
]
```

**Status Codes**:
- `200 OK`: Request successful
- `401 Unauthorized`: Invalid or missing token

#### Get Email Provider

**Endpoint**: `GET /ingestion/providers/{provider_id}`

**Description**: Returns a specific email provider configuration.

**Authentication**: Required

**Parameters**:
- `provider_id`: ID of the email provider

**Response**:
```json
{
  "id": "provider_id",
  "type": "gmail",
  "server": "imap.gmail.com",
  "username": "your_email@gmail.com",
  "folder": "INBOX",
  "limit": 10,
  "created_at": "2025-04-14T08:00:00Z"
}
```

**Status Codes**:
- `200 OK`: Request successful
- `404 Not Found`: Provider not found
- `401 Unauthorized`: Invalid or missing token

#### Update Email Provider

**Endpoint**: `PUT /ingestion/providers/{provider_id}`

**Description**: Updates a specific email provider configuration.

**Authentication**: Required

**Parameters**:
- `provider_id`: ID of the email provider

**Request Body**:
```json
{
  "type": "gmail",
  "server": "imap.gmail.com",
  "username": "your_email@gmail.com",
  "password": "your_new_password",
  "folder": "INBOX",
  "limit": 15
}
```

**Response**:
```json
{
  "id": "provider_id",
  "type": "gmail",
  "server": "imap.gmail.com",
  "username": "your_email@gmail.com",
  "folder": "INBOX",
  "limit": 15,
  "created_at": "2025-04-14T08:00:00Z"
}
```

**Status Codes**:
- `200 OK`: Provider updated successfully
- `400 Bad Request`: Invalid request body
- `404 Not Found`: Provider not found
- `401 Unauthorized`: Invalid or missing token

#### Delete Email Provider

**Endpoint**: `DELETE /ingestion/providers/{provider_id}`

**Description**: Deletes a specific email provider configuration.

**Authentication**: Required

**Parameters**:
- `provider_id`: ID of the email provider

**Response**:
```json
{
  "message": "Provider deleted successfully"
}
```

**Status Codes**:
- `200 OK`: Provider deleted successfully
- `404 Not Found`: Provider not found
- `401 Unauthorized`: Invalid or missing token

#### Fetch Emails

**Endpoint**: `POST /ingestion/fetch`

**Description**: Fetches emails from a specific provider.

**Authentication**: Required

**Request Body**:
```json
{
  "provider_id": "provider_id",
  "limit": 10
}
```

**Response**:
```json
{
  "emails_fetched": 5,
  "provider_id": "provider_id",
  "status": "success"
}
```

**Status Codes**:
- `200 OK`: Emails fetched successfully
- `400 Bad Request`: Invalid request body
- `404 Not Found`: Provider not found
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error fetching emails

### Classification

#### Classify Email

**Endpoint**: `POST /classification/classify`

**Description**: Classifies an email into predefined categories.

**Authentication**: Required

**Request Body**:
```json
{
  "message_id": "message_id",
  "subject": "Project Update Meeting",
  "from_address": "john.doe@example.com",
  "to": "recipient@example.com",
  "cc": "team@example.com",
  "body": "Hello team,\n\nLet's schedule a project update meeting for tomorrow at 2 PM. We need to discuss the current progress and next steps.\n\nRegards,\nJohn",
  "attachments": []
}
```

**Response**:
```json
{
  "message_id": "message_id",
  "predicted_category": "important",
  "confidence": 0.85,
  "category_probabilities": {
    "important": 0.85,
    "promotional": 0.05,
    "support": 0.07,
    "spam": 0.01,
    "other": 0.02
  }
}
```

**Status Codes**:
- `200 OK`: Email classified successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error classifying email

#### Get Classification Categories

**Endpoint**: `GET /classification/categories`

**Description**: Returns the list of available classification categories.

**Authentication**: Required

**Response**:
```json
{
  "categories": ["important", "promotional", "support", "spam", "other"]
}
```

**Status Codes**:
- `200 OK`: Request successful
- `401 Unauthorized`: Invalid or missing token

### Summarization

#### Summarize Email

**Endpoint**: `POST /summarization/summarize`

**Description**: Generates a summary of an email.

**Authentication**: Required

**Request Body**:
```json
{
  "message_id": "message_id",
  "subject": "Project Update Meeting",
  "from_address": "john.doe@example.com",
  "to": "recipient@example.com",
  "cc": "team@example.com",
  "body": "Hello team,\n\nLet's schedule a project update meeting for tomorrow at 2 PM. We need to discuss the current progress and next steps.\n\nRegards,\nJohn",
  "attachments": [],
  "classification": {
    "predicted_category": "important",
    "confidence": 0.85
  }
}
```

**Response**:
```json
{
  "message_id": "message_id",
  "summary": "Project update meeting scheduled for tomorrow at 2 PM to discuss progress and next steps."
}
```

**Status Codes**:
- `200 OK`: Email summarized successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error summarizing email

#### Extract Data

**Endpoint**: `POST /summarization/extract`

**Description**: Extracts key data points from an email.

**Authentication**: Required

**Request Body**:
```json
{
  "message_id": "message_id",
  "subject": "Project Update Meeting",
  "from_address": "john.doe@example.com",
  "to": "recipient@example.com",
  "cc": "team@example.com",
  "body": "Hello team,\n\nLet's schedule a project update meeting for tomorrow at 2 PM. We need to discuss the current progress and next steps.\n\nRegards,\nJohn",
  "attachments": [],
  "classification": {
    "predicted_category": "important",
    "confidence": 0.85
  }
}
```

**Response**:
```json
{
  "message_id": "message_id",
  "extractions": {
    "dates_times": [
      {
        "text": "tomorrow at 2 PM",
        "type": "datetime"
      }
    ],
    "contacts": [
      {
        "text": "John",
        "type": "person"
      }
    ],
    "tasks": [
      {
        "text": "discuss the current progress and next steps",
        "type": "task"
      }
    ]
  }
}
```

**Status Codes**:
- `200 OK`: Data extracted successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error extracting data

### Response Generation

#### Generate Response

**Endpoint**: `POST /response/generate`

**Description**: Generates a response to an email.

**Authentication**: Required

**Request Body**:
```json
{
  "message_id": "message_id",
  "subject": "Project Update Meeting",
  "from_address": "john.doe@example.com",
  "to": "recipient@example.com",
  "cc": "team@example.com",
  "body": "Hello team,\n\nLet's schedule a project update meeting for tomorrow at 2 PM. We need to discuss the current progress and next steps.\n\nRegards,\nJohn",
  "attachments": [],
  "classification": {
    "predicted_category": "important",
    "confidence": 0.85
  },
  "processed_data": {
    "summary": "Project update meeting scheduled for tomorrow at 2 PM to discuss progress and next steps.",
    "extractions": {
      "dates_times": [
        {
          "text": "tomorrow at 2 PM",
          "type": "datetime"
        }
      ],
      "contacts": [
        {
          "text": "John",
          "type": "person"
        }
      ],
      "tasks": [
        {
          "text": "discuss the current progress and next steps",
          "type": "task"
        }
      ]
    }
  }
}
```

**Response**:
```json
{
  "message_id": "message_id",
  "response_text": "Thank you for your important message. I've reviewed it and noted the project update meeting scheduled for tomorrow at 2 PM to discuss progress and next steps. I'll attend as requested.",
  "auto_send": true,
  "confidence": 0.92,
  "category": "important",
  "generation_timestamp": "2025-04-14T08:30:00Z"
}
```

**Status Codes**:
- `200 OK`: Response generated successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error generating response

#### Get Response Templates

**Endpoint**: `GET /response/templates`

**Description**: Returns the list of available response templates.

**Authentication**: Required

**Query Parameters**:
- `category` (optional): Filter templates by category

**Response**:
```json
[
  {
    "id": "template_id_1",
    "category": "important",
    "template": "Thank you for your important message. I've reviewed it and {summary}. I'll {action} as requested.",
    "timestamp": "2025-04-14T08:00:00Z"
  },
  {
    "id": "template_id_2",
    "category": "support",
    "template": "Thank you for reaching out to our support team. I understand that {summary}. We'll {action} to resolve this issue.",
    "timestamp": "2025-04-14T08:00:00Z"
  }
]
```

**Status Codes**:
- `200 OK`: Request successful
- `401 Unauthorized`: Invalid or missing token

#### Create Response Template

**Endpoint**: `POST /response/templates`

**Description**: Creates a new response template.

**Authentication**: Required

**Request Body**:
```json
{
  "category": "important",
  "template": "Thank you for your important message. I've reviewed it and {summary}. I'll {action} as requested."
}
```

**Response**:
```json
{
  "id": "template_id",
  "category": "important",
  "template": "Thank you for your important message. I've reviewed it and {summary}. I'll {action} as requested.",
  "timestamp": "2025-04-14T08:30:00Z"
}
```

**Status Codes**:
- `200 OK`: Template created successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token

### Integration

#### Create Calendar Event

**Endpoint**: `POST /integration/calendar`

**Description**: Creates a calendar event based on email content.

**Authentication**: Required

**Request Body**:
```json
{
  "message_id": "message_id",
  "subject": "Project Update Meeting",
  "from_address": "john.doe@example.com",
  "to": "recipient@example.com",
  "cc": "team@example.com",
  "body": "Hello team,\n\nLet's schedule a project update meeting for tomorrow at 2 PM. We need to discuss the current progress and next steps.\n\nRegards,\nJohn",
  "attachments": [],
  "classification": {
    "predicted_category": "important",
    "confidence": 0.85
  },
  "processed_data": {
    "summary": "Project update meeting scheduled for tomorrow at 2 PM to discuss progress and next steps.",
    "extractions": {
      "dates_times": [
        {
          "text": "tomorrow at 2 PM",
          "type": "datetime"
        }
      ],
      "contacts": [
        {
          "text": "John",
          "type": "person"
        }
      ],
      "tasks": [
        {
          "text": "discuss the current progress and next steps",
          "type": "task"
        }
      ]
    }
  }
}
```

**Response**:
```json
{
  "service": "google_calendar",
  "events_created": [
    {
      "id": "event_id",
      "title": "Project Update Meeting",
      "datetime": "2025-04-15T14:00:00Z",
      "description": "Project update meeting to discuss progress and next steps.",
      "attendees": ["john.doe@example.com", "recipient@example.com", "team@example.com"],
      "location": null,
      "duration_minutes": 60
    }
  ],
  "status": "success",
  "timestamp": "2025-04-14T08:30:00Z"
}
```

**Status Codes**:
- `200 OK`: Calendar event created successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error creating calendar event

#### Update CRM Contacts

**Endpoint**: `POST /integration/crm`

**Description**: Updates CRM contacts based on email content.

**Authentication**: Required

**Request Body**:
```json
{
  "message_id": "message_id",
  "subject": "Project Update Meeting",
  "from_address": "john.doe@example.com",
  "to": "recipient@example.com",
  "cc": "team@example.com",
  "body": "Hello team,\n\nLet's schedule a project update meeting for tomorrow at 2 PM. We need to discuss the current progress and next steps.\n\nRegards,\nJohn",
  "attachments": [],
  "classification": {
    "predicted_category": "important",
    "confidence": 0.85
  },
  "processed_data": {
    "summary": "Project update meeting scheduled for tomorrow at 2 PM to discuss progress and next steps.",
    "extractions": {
      "dates_times": [
        {
          "text": "tomorrow at 2 PM",
          "type": "datetime"
        }
      ],
      "contacts": [
        {
          "text": "John",
          "type": "person"
        }
      ],
      "tasks": [
        {
          "text": "discuss the current progress and next steps",
          "type": "task"
        }
      ]
    }
  }
}
```

**Response**:
```json
{
  "service": "salesforce",
  "contacts_updated": [
    {
      "id": "contact_id",
      "email": "john.doe@example.com",
      "name": "John Doe",
      "company": "Example Inc.",
      "notes": "Last contact: Project update meeting scheduled for tomorrow at 2 PM."
    }
  ],
  "status": "success",
  "timestamp": "2025-04-14T08:30:00Z"
}
```

**Status Codes**:
- `200 OK`: CRM contacts updated successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error updating CRM contacts

#### Create Tasks

**Endpoint**: `POST /integration/tasks`

**Description**: Creates tasks based on email content.

**Authentication**: Required

**Request Body**:
```json
{
  "message_id": "message_id",
  "subject": "Project Update Meeting",
  "from_address": "john.doe@example.com",
  "to": "recipient@example.com",
  "cc": "team@example.com",
  "body": "Hello team,\n\nLet's schedule a project update meeting for tomorrow at 2 PM. We need to discuss the current progress and next steps.\n\nRegards,\nJohn",
  "attachments": [],
  "classification": {
    "predicted_category": "important",
    "confidence": 0.85
  },
  "processed_data": {
    "summary": "Project update meeting scheduled for tomorrow at 2 PM to discuss progress and next steps.",
    "extractions": {
      "dates_times": [
        {
          "text": "tomorrow at 2 PM",
          "type": "datetime"
        }
      ],
      "contacts": [
        {
          "text": "John",
          "type": "person"
        }
      ],
      "tasks": [
        {
          "text": "discuss the current progress and next steps",
          "type": "task"
        }
      ]
    }
  }
}
```

**Response**:
```json
{
  "service": "asana",
  "tasks_created": [
    {
      "id": "task_id",
      "title": "Prepare for Project Update Meeting",
      "description": "Prepare to discuss the current progress and next steps at the project update meeting.",
      "due_date": "2025-04-15T14:00:00Z",
      "priority": "medium",
      "assignee": "recipient@example.com"
    }
  ],
  "status": "success",
  "timestamp": "2025-04-14T08:30:00Z"
}
```

**Status Codes**:
- `200 OK`: Tasks created successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error creating tasks

#### Run Workflow

**Endpoint**: `POST /integration/workflow`

**Description**: Runs the complete email processing workflow.

**Authentication**: Required

**Request Body**:
```json
[
  {
    "message_id": "message_id_1",
    "subject": "Project Update Meeting",
    "from_address": "john.doe@example.com",
    "to": "recipient@example.com",
    "cc": "team@example.com",
    "body": "Hello team,\n\nLet's schedule a project update meeting for tomorrow at 2 PM. We need to discuss the current progress and next steps.\n\nRegards,\nJohn",
    "attachments": []
  },
  {
    "message_id": "message_id_2",
    "subject": "Weekly Newsletter",
    "from_address": "newsletter@company.com",
    "to": "recipient@example.com",
    "cc": null,
    "body": "This week's newsletter includes updates on new products, upcoming events, and company announcements. Check out our latest blog post!",
    "attachments": []
  }
]
```

**Response**:
```json
{
  "start_time": "2025-04-14T08:30:00Z",
  "end_time": "2025-04-14T08:30:05Z",
  "duration_seconds": 5.0,
  "emails_processed": 2,
  "emails_with_responses": 2,
  "emails_auto_sent": 1,
  "emails_with_calendar_integration": 1,
  "emails_with_crm_integration": 1,
  "emails_with_task_integration": 1,
  "status": "completed",
  "error": null
}
```

**Status Codes**:
- `200 OK`: Workflow completed successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error running workflow

### Settings

#### Get Settings

**Endpoint**: `GET /settings`

**Description**: Returns the current system settings.

**Authentication**: Required

**Response**:
```json
{
  "database": {
    "mongodb_url": "mongodb://localhost:27017",
    "database_name": "email_automation"
  },
  "cache": {
    "redis_host": "localhost",
    "redis_port": 6379,
    "redis_db": 0
  },
  "api": {
    "host": "0.0.0.0",
    "port": 8000,
    "debug": true,
    "cors_origins": ["*"]
  },
  "email_ingestion": {
    "batch_size": 10,
    "polling_interval": 300
  },
  "classification": {
    "model_type": "bert",
    "categories": ["important", "promotional", "support", "spam", "other"],
    "threshold": 0.7
  },
  "summarization": {
    "model_type": "gpt",
    "summary_max_length": 150
  },
  "response_generation": {
    "model_type": "gpt",
    "auto_send_threshold": 0.9,
    "templates": {
      "important": "Thank you for your important message. I've reviewed it and {summary}. I'll {action} as requested.",
      "support": "Thank you for reaching out to our support team. I understand that {summary}. We'll {action} to resolve this issue.",
      "promotional": "Thank you for sharing this offer. I'll review the details about {summary} and get back to you if interested.",
      "spam": "",
      "other": "Thank you for your message. I've noted that {summary}. I'll get back to you soon."
    }
  },
  "integration": {
    "workflow": {
      "auto_send_enabled": true,
      "batch_size": 10
    },
    "integrations": {
      "calendar": {
        "enabled": true,
        "service": "google_calendar"
      },
      "crm": {
        "enabled": true,
        "service": "salesforce"
      },
      "task_manager": {
        "enabled": true,
        "service": "asana"
      }
    }
  },
  "logging": {
    "level": "INFO",
    "file": "logs/email_automation.log",
    "max_size": 10485760,
    "backup_count": 5
  }
}
```

**Status Codes**:
- `200 OK`: Request successful
- `401 Unauthorized`: Invalid or missing token

#### Update Settings

**Endpoint**: `PUT /settings`

**Description**: Updates the system settings.

**Authentication**: Required

**Request Body**:
```json
{
  "email_ingestion": {
    "batch_size": 20,
    "polling_interval": 600
  },
  "classification": {
    "threshold": 0.8
  },
  "integration": {
    "workflow": {
      "auto_send_enabled": false
    }
  }
}
```

**Response**:
```json
{
  "message": "Settings updated successfully"
}
```

**Status Codes**:
- `200 OK`: Settings updated successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token
- `500 Internal Server Error`: Error updating settings

### Analytics

#### Get Email Analytics

**Endpoint**: `GET /analytics/emails`

**Description**: Returns analytics data for email processing.

**Authentication**: Required

**Query Parameters**:
- `start_date` (optional): Start date for analytics (ISO format)
- `end_date` (optional): End date for analytics (ISO format)
- `limit` (optional): Maximum number of records to return (default: 100)

**Response**:
```json
{
  "total_emails": 152,
  "emails_by_category": {
    "important": 35,
    "promotional": 40,
    "support": 15,
    "spam": 5,
    "other": 5
  },
  "emails_by_day": [
    {
      "date": "2025-04-08",
      "count": 32
    },
    {
      "date": "2025-04-09",
      "count": 45
    },
    {
      "date": "2025-04-10",
      "count": 38
    },
    {
      "date": "2025-04-11",
      "count": 52
    },
    {
      "date": "2025-04-12",
      "count": 48
    },
    {
      "date": "2025-04-13",
      "count": 23
    },
    {
      "date": "2025-04-14",
      "count": 18
    }
  ],
  "response_rate": 0.89,
  "auto_send_rate": 0.65,
  "average_processing_time": 3.2
}
```

**Status Codes**:
- `200 OK`: Request successful
- `401 Unauthorized`: Invalid or missing token

#### Get Integration Analytics

**Endpoint**: `GET /analytics/integrations`

**Description**: Returns analytics data for integrations.

**Authentication**: Required

**Query Parameters**:
- `start_date` (optional): Start date for analytics (ISO format)
- `end_date` (optional): End date for analytics (ISO format)
- `limit` (optional): Maximum number of records to return (default: 100)

**Response**:
```json
{
  "total_integrations": 143,
  "integrations_by_type": {
    "calendar": 42,
    "crm": 78,
    "task_manager": 23
  },
  "integrations_by_day": [
    {
      "date": "2025-04-08",
      "count": 18
    },
    {
      "date": "2025-04-09",
      "count": 25
    },
    {
      "date": "2025-04-10",
      "count": 20
    },
    {
      "date": "2025-04-11",
      "count": 30
    },
    {
      "date": "2025-04-12",
      "count": 28
    },
    {
      "date": "2025-04-13",
      "count": 12
    },
    {
      "date": "2025-04-14",
      "count": 10
    }
  ],
  "success_rate": 0.95
}
```

**Status Codes**:
- `200 OK`: Request successful
- `401 Unauthorized`: Invalid or missing token

## Error Handling

All API endpoints return appropriate HTTP status codes and error messages in case of failure. Error responses have the following format:

```json
{
  "detail": "Error message describing the issue"
}
```

Common error codes:
- `400 Bad Request`: Invalid request parameters or body
- `401 Unauthorized`: Invalid or missing authentication token
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Server-side error

## Rate Limiting

The API implements rate limiting to prevent abuse. Rate limits are applied per user and are reset hourly.

Rate limit headers are included in all API responses:
- `X-RateLimit-Limit`: Maximum number of requests allowed per hour
- `X-RateLimit-Remaining`: Number of requests remaining in the current hour
- `X-RateLimit-Reset`: Time (in seconds) until the rate limit resets

When rate limit is exceeded, the API returns a `429 Too Many Requests` status code.

## Versioning

The API uses URL versioning. The current version is v1, which is implied in the base URL. Future versions will be explicitly specified in the URL:

```
https://your-server-address/v2/...
```

## Webhooks

The API supports webhooks for real-time notifications of events. Webhooks can be configured through the `/webhooks` endpoint.

### Create Webhook

**Endpoint**: `POST /webhooks`

**Description**: Creates a new webhook subscription.

**Authentication**: Required

**Request Body**:
```json
{
  "url": "https://your-server.com/webhook-handler",
  "events": ["email.received", "email.classified", "response.generated"],
  "secret": "your_webhook_secret"
}
```

**Response**:
```json
{
  "id": "webhook_id",
  "url": "https://your-server.com/webhook-handler",
  "events": ["email.received", "email.classified", "response.generated"],
  "created_at": "2025-04-14T08:30:00Z"
}
```

**Status Codes**:
- `200 OK`: Webhook created successfully
- `400 Bad Request`: Invalid request body
- `401 Unauthorized`: Invalid or missing token

### Webhook Payload

When an event occurs, the API sends a POST request to the webhook URL with the following payload:

```json
{
  "event": "email.classified",
  "timestamp": "2025-04-14T08:30:00Z",
  "data": {
    "message_id": "message_id",
    "predicted_category": "important",
    "confidence": 0.85
  }
}
```

The request includes an `X-Webhook-Signature` header that can be used to verify the authenticity of the webhook.
