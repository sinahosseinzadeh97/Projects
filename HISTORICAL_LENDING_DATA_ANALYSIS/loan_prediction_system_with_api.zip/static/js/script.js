// Main JavaScript for Loan Prediction System

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Loan Prediction System initialized');
    
    // Initialize tab functionality
    initTabs();
    
    // Add event listeners to forms
    initFormListeners();
});

// Initialize tab functionality
function initTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    
    if (tabButtons.length > 0) {
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons and panes
                document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
                
                // Add active class to clicked button
                button.classList.add('active');
                
                // Show corresponding pane
                const tabId = button.getAttribute('data-tab');
                const tabPane = document.getElementById(tabId);
                if (tabPane) {
                    tabPane.classList.add('active');
                }
            });
        });
    }
}

// Initialize form listeners
function initFormListeners() {
    // Debt profile selector
    const debtProfileSelect = document.getElementById('debt-profile');
    if (debtProfileSelect) {
        debtProfileSelect.addEventListener('change', function() {
            const customInputs = document.getElementById('custom-debt-inputs');
            if (customInputs) {
                if (this.value === 'custom') {
                    customInputs.style.display = 'block';
                } else {
                    customInputs.style.display = 'none';
                }
            }
        });
    }
}

// Format currency values
function formatCurrency(value) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2
    }).format(value);
}

// Format percentage values
function formatPercent(value) {
    return new Intl.NumberFormat('en-US', {
        style: 'percent',
        minimumFractionDigits: 2
    }).format(value / 100);
}
